<?php

/**
 *
 * @author thiagovalentim
 */
namespace Fuzzy\Inference;

interface InferenceInterface
{
    //put your code here
}
