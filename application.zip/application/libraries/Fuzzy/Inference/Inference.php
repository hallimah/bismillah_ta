<?php

/**
 * Description of Inference
 *
 * @author thiagovalentim
 */
namespace Fuzzy\Inference;

class Inference extends InferenceAbstract
{
    
}
