<?php

/**
 *
 * @author thiagovalentim
 */
namespace Fuzzy\Inference\Method;

interface MethodInterface
{
    public function getRules();
}
