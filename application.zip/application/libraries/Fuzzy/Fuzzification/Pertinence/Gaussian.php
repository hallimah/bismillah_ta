<?php

/**
 * Description of Gaussian
 *
 * @author thiagovalentim
 */
namespace Fuzzy\Fuzzification\Pertinence;

class Gaussian
{
    
}
