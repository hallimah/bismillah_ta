<?php

/**
 *
 * @author thiagovalentim
 */
namespace Fuzzy\Fuzzification\Pertinence;

interface PertinenceInterface
{

}
