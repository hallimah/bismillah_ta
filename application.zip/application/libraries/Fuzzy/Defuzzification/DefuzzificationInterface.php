<?php
namespace Fuzzy\Defuzzification;

/**
 *
 * @author Thiago Valentim
 *        
 */

interface DefuzzificationInterface
{
    public function calculate();
}
