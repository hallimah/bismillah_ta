<?php

class m_backup extends CI_Model{

    function backup_klasifikasi_kecamatan(){
        
    }
}
?>